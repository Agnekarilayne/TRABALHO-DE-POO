public class BlocoTipo {
    public static int Fundo = 0;
    public static int Bloco1 = 1;
    public static int Bloco2 = 2;
    public static int Bloco3 = 3;
    public static int Bloco4 = 4;
}
